import nltk
import re
import pandas as pd
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

# Download necessary datasets
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('omw-1.4')

# Load the dataset from CSV
file_path = "text_dataset.csv"  # Make sure the file is in the same directory
df = pd.read_csv(file_path)

# Initialize NLP tools
stop_words = set(stopwords.words('english'))
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

# Function to preprocess text
def preprocess_text(text):
    # Tokenization
    words = word_tokenize(text)
    
    # Lowercasing
    words_lower = [word.lower() for word in words]
    
    # Removing Punctuation & Special Characters
    words_clean = [re.sub(r'[^\w\s]', '', word) for word in words_lower if word.isalnum()]
    
    # Removing Stopwords
    words_no_stop = [word for word in words_clean if word not in stop_words]
    
    # Stemming
    words_stemmed = [stemmer.stem(word) for word in words_no_stop]
    
    # Lemmatization
    words_lemmatized = [lemmatizer.lemmatize(word) for word in words_no_stop]
    
    return {
        "original_text": text,
        "tokenized": words,
        "no_stopwords": words_no_stop,
        "stemmed": words_stemmed,
        "lemmatized": words_lemmatized
    }

# Apply preprocessing to each text entry
df["processed"] = df["text"].apply(preprocess_text)

# Convert sentences into Bag of Words (BoW) and TF-IDF format
vectorizer = CountVectorizer()
tfidf_vectorizer = TfidfVectorizer()

# Fit and transform the text column
bow_matrix = vectorizer.fit_transform(df["text"])
tfidf_matrix = tfidf_vectorizer.fit_transform(df["text"])

# Convert matrix to DataFrame for better visualization
df_bow = pd.DataFrame(bow_matrix.toarray(), columns=vectorizer.get_feature_names_out())
df_tfidf = pd.DataFrame(tfidf_matrix.toarray(), columns=tfidf_vectorizer.get_feature_names_out())

# Display results
print("Processed Data:\n", df[["id", "processed"]])
print("\nBag of Words Representation:\n", df_bow)
print("\nTF-IDF Representation:\n", df_tfidf)
